from __future__ import annotations

from django.db import models
from django.db.models import QuerySet

from .models import Asociacion, AsociacionUsuario, ExpedienteCAIMUS, ItemChecklistCAIMUS


def is_informatica(user) -> bool:
    return (
        user.is_authenticated
        and user.groups.filter(name__iexact="Informatica").exists()
    )


def is_administrador(user) -> bool:
    return (
        user.is_authenticated
        and user.groups.filter(name__iexact="Administrador").exists()
    )


def is_admin_operativo(user) -> bool:
    return (
        user.is_authenticated
        and (
            is_administrador(user)
            or is_informatica(user)
        )
    )


def can_manage_config(user) -> bool:
    return is_informatica(user)


def is_admin(user) -> bool:
    return is_admin_operativo(user)


def is_asociacion(user) -> bool:
    if not user.is_authenticated:
        return False
    return user.groups.filter(name__iexact="Asociacion").exists()


def get_asociaciones_usuario(user) -> QuerySet[Asociacion]:
    if not user.is_authenticated:
        return Asociacion.objects.none()
    return Asociacion.objects.filter(
        activo=True,
        usuarios__usuario=user,
        usuarios__activo=True,
    ).distinct()


def user_has_asociacion_access(user, asociacion: Asociacion) -> bool:
    if is_admin(user):
        return True
    if not is_asociacion(user):
        return False
    return AsociacionUsuario.objects.filter(
        usuario=user,
        asociacion=asociacion,
        activo=True,
        asociacion__activo=True,
    ).exists()


def user_has_expediente_access(user, expediente: ExpedienteCAIMUS) -> bool:
    return user_has_asociacion_access(user, expediente.asociacion)


def expediente_esta_completo(expediente: ExpedienteCAIMUS) -> bool:
    items = expediente.items.filter(activo=True)
    if not items.exists():
        return False
    return not items.filter(models.Q(pdf="") | models.Q(pdf__isnull=True)).exists()


def expediente_items_100_aprobados(expediente: ExpedienteCAIMUS) -> bool:
    items = expediente.items.filter(activo=True)
    if not items.exists():
        return False
    return not items.exclude(estado_item=ItemChecklistCAIMUS.ESTADO_APROBADO).exists()


def user_can_download_resolucion(user, expediente: ExpedienteCAIMUS) -> bool:
    if expediente.estado != ExpedienteCAIMUS.ESTADO_APROBADO:
        return False
    if not expediente_items_100_aprobados(expediente):
        return False
    if is_admin(user):
        return True
    if not is_asociacion(user):
        return False
    tiene_asignacion = AsociacionUsuario.objects.filter(
        usuario=user,
        asociacion=expediente.asociacion,
        activo=True,
        asociacion__activo=True,
    ).exists()
    return tiene_asignacion and expediente_esta_completo(expediente)
